package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ProfileActivity extends AppCompatActivity {

    // Объявление кнопок для настроек и выхода
    private AppCompatButton settingButton, exitButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Включение режима Edge-to-Edge
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_profile);

        // Настройка отступов
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (view, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Инициализация кнопок
        settingButton = findViewById(R.id.setting_btn);
        exitButton = findViewById(R.id.exit_btn);

        // Установка обработчика нажатия для кнопки настроек
        settingButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Переход к SettingsActivity при нажатии на кнопку настроек
                Intent settingIntent = new Intent(ProfileActivity.this, SettingsActivity.class);
                startActivity(settingIntent);
            }
        });

        // Установка обработчика нажатия для кнопки выхода
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Переход к MainActivity при нажатии на кнопку выхода
                Intent backIntent = new Intent(ProfileActivity.this, MainActivity.class);
                startActivity(backIntent);
            }
        });
    }
}
